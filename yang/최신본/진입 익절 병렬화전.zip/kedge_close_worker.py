# -*- coding: utf-8 -*-
"""
K-EDGE V9.5.2 CLOSE WORKER - first skeleton
- Central place for exit monitoring.
- This first version initializes the core and prints ACTIVE positions.
- Next patch will attach real current-edge scan + ghost/partial close cleanup.
"""
import os, sys, time, glob, importlib.util, traceback
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
POLL_SEC = float(os.getenv("CLOSE_WORKER_POLL_SEC", "5"))


def load_core():
    candidates = sorted(glob.glob(os.path.join(BASE_DIR, "kedge_v9_5_2_SCAN_QUEUE_MEXC.py")))
    if not candidates:
        candidates = sorted(glob.glob(os.path.join(BASE_DIR, "kedge*_MEXC*.py")))
    if not candidates:
        print("[FATAL] MEXC core file not found")
        sys.exit(1)
    target = candidates[-1]
    spec = importlib.util.spec_from_file_location("kedge_core_close", target)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    print(f"[CLOSE WORKER] core loaded: {os.path.basename(target)}")
    return module

core = load_core()
try:
    core.ENABLE_CALLBACK_POLLER = True
    _, future_exs = core.init_ccxt_all()
    core.GLOBAL_FUTURE_EXS = core.init_callback_future_exs(future_exs)
    print(f"[CLOSE WORKER] GLOBAL_FUTURE_EXS={sorted(core.GLOBAL_FUTURE_EXS.keys())}")
except Exception as e:
    print(f"[CLOSE WORKER] futures init warning: {e}")


def main():
    print("="*70)
    print("K-EDGE V9.5.2 CLOSE WORKER - MONITOR SKELETON")
    print("This version does not place close orders yet.")
    print("Next patch: current edge check + foreign-first close + ghost cleanup.")
    print("="*70)
    while True:
        try:
            positions = core.get_active_positions_all_files()
            print(f"[CLOSE WORKER] ACTIVE positions={len(positions)} / {core.now_str()}")
            for p in positions[:20]:
                print(f" - {p.get('coin')} {p.get('domestic')}->{p.get('foreign')} status={p.get('status')} pos={p.get('pos_id')}")
        except Exception as e:
            print("[CLOSE WORKER ERROR]", e)
            traceback.print_exc()
        time.sleep(POLL_SEC)

if __name__ == "__main__":
    main()
