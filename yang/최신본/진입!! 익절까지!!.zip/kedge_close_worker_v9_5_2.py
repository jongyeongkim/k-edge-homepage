# -*- coding: utf-8 -*-
"""
K-EDGE V9.5.2 CLOSE WORKER - REAL 0.3% TAKE-PROFIT PATCH

역할
- 4개 state 파일(semi_auto_state_mexc/gate/bitget/bingx.json)의 ACTIVE/OPEN 포지션 감시
- 현재 실제엣지 계산: 국내 현물 ask vs 해외 선물 bid - BTC 기준괴리
- 현재 실제엣지 <= take_profit_edge(기본 +0.3%) 최초 도달 시 TP_TRIGGER 저장
- 이후 현재엣지가 TP_TRIGGER_CLOSE_MAX_EDGE(기본 +0.5%) 안이면 청산 계속 재시도
- 청산 순서: 해외 숏 buy reduceOnly 성공 확인 -> 빗썸 현물 sell
- 둘 다 성공해야 AUTO_CLOSED 처리
- 한쪽만 성공/실패 시 FUTURES_CLOSED_ONLY/SPOT_CLOSED_ONLY/ACTIVE 유지 후 재시도

주의
- Scanner 4파일은 후보를 order_queue.jsonl에만 저장한다.
- ORDER WORKER는 진입 담당.
- CLOSE WORKER는 청산 담당.
"""

import os
import sys
import time
import glob
import json
import importlib.util
import traceback
from typing import Any, Dict, Tuple, Optional

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
POLL_SEC = float(os.getenv("CLOSE_WORKER_POLL_SEC", "5"))
CLOSE_RETRY_SEC = float(os.getenv("CLOSE_WORKER_RETRY_SEC", "20"))
MAX_POSITIONS_PRINT = int(os.getenv("CLOSE_WORKER_MAX_PRINT", "30"))
DRY_RUN = os.getenv("CLOSE_WORKER_DRY_RUN", "false").lower() == "true"
TP_TRIGGER_CLOSE_MAX_EDGE = float(os.getenv("TP_TRIGGER_CLOSE_MAX_EDGE", "0.5"))
FAIL_DM_COOLDOWN_SEC = float(os.getenv("CLOSE_FAIL_DM_COOLDOWN_SEC", "300"))

# 동일 포지션에 청산 주문이 중복 발사되는 것 방지용 메모리 락
_CLOSING_POS_IDS = set()
_LAST_CLOSE_ATTEMPT_AT: Dict[str, float] = {}
_LAST_FAIL_DM_AT: Dict[str, float] = {}


def load_core():
    candidates = sorted(glob.glob(os.path.join(BASE_DIR, "kedge_v9_5_2_SCAN_QUEUE_MEXC.py")))
    if not candidates:
        candidates = sorted(glob.glob(os.path.join(BASE_DIR, "kedge*_MEXC*.py")))
    if not candidates:
        print("[FATAL] MEXC core file not found")
        sys.exit(1)
    target = candidates[-1]
    spec = importlib.util.spec_from_file_location("kedge_core_close", target)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    print(f"[CLOSE WORKER] core loaded: {os.path.basename(target)}")
    return module


core = load_core()

try:
    # CLOSE WORKER는 모든 해외 선물 객체가 필요하다.
    core.ENABLE_CALLBACK_POLLER = True
    _, future_exs = core.init_ccxt_all()
    core.GLOBAL_FUTURE_EXS = core.init_callback_future_exs(future_exs)
    print(f"[CLOSE WORKER] GLOBAL_FUTURE_EXS={sorted(core.GLOBAL_FUTURE_EXS.keys())}")
except Exception as e:
    print(f"[CLOSE WORKER] futures init warning: {e}")

# Scanner 쪽 청산은 꺼져 있어도 CLOSE WORKER 자체는 청산해야 하므로 강제로 켠다.
try:
    core.AUTO_CLOSE_ENABLED = True
except Exception:
    pass


def read_json(path: str, default: Any) -> Any:
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception as e:
        print(f"[STATE READ FAIL] {path} / {e}")
    return default


def write_json_atomic(path: str, data: Any) -> None:
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def update_position_in_own_state_file(pos: Dict[str, Any], fields: Dict[str, Any]) -> None:
    """get_active_positions_all_files()가 준 _state_path에 정확히 업데이트한다.

    core.mark_position_closed()는 MEXC 기본 state만 업데이트할 수 있으므로
    4파일 구조에서는 반드시 원래 state 파일을 직접 수정해야 한다.
    """
    pos_id = str(pos.get("pos_id") or "")
    state_path = str(pos.get("_state_path") or "")
    if not pos_id or not state_path:
        print(f"[STATE UPDATE SKIP] pos_id/state_path missing pos_id={pos_id} path={state_path}")
        return
    state = read_json(state_path, {})
    positions = state.setdefault("positions", {})
    saved = positions.get(pos_id)
    if not isinstance(saved, dict):
        print(f"[STATE UPDATE SKIP] position not found in {os.path.basename(state_path)} pos={pos_id}")
        return
    saved.update(fields)
    write_json_atomic(state_path, state)
    print(f"[STATE UPDATE] {os.path.basename(state_path)} / {pos.get('coin')} / {fields.get('status', saved.get('status'))}")


def mark_position_closed_in_own_file(pos: Dict[str, Any], status: str, current_edge: float, reason: str) -> None:
    fields = {
        "status": status,
        "closed_at": core.now_str(),
        "close_edge": round(float(current_edge), 4),
        "close_reason": str(reason),
        "futures_closed": True,
        "spot_closed": True,
    }
    update_position_in_own_state_file(pos, fields)
    try:
        # PAPER_TRADING_ENABLED=False이면 내부에서 자동 SKIP됨.
        core.paper_record_close(str(pos.get("pos_id") or ""), dict(pos), status, current_edge, reason)
    except Exception as e:
        print(f"[PAPER CLOSE RECORD WARN] {e}")


def send_position_dm(pos: Dict[str, Any], title: str, body: str, current_edge: float) -> None:
    user_id = str(pos.get("user_id") or pos.get("tg_chat_id") or "").strip()
    entry_edge = core.safe_float(pos.get("entry_edge"))
    take_profit_edge = core.safe_float(pos.get("take_profit_edge"), core.AUTO_TAKE_PROFIT_EDGE_PERCENT)
    msg = f"""{title}

코인: {pos.get('coin')}
경로: {pos.get('domestic')} 현물 + {pos.get('foreign')} 선물숏
금액: {core.fmt_man_krw(pos.get('amount_krw') or pos.get('domestic_entry_krw'))}

진입 실제엣지: {entry_edge:+.2f}%
현재 실제엣지: {current_edge:+.2f}%
익절 기준: {take_profit_edge:+.2f}% 이하

{body}

🕒 {core.now_str()}"""
    try:
        if user_id:
            core.telegram_send_private(user_id, msg)
        # 익절/실패는 VIP에도 남긴다.
        core.telegram_send(msg)
    except Exception as e:
        print(f"[CLOSE DM WARN] {e}")


def compute_current_edge(pos: Dict[str, Any]) -> Tuple[bool, float, str]:
    """현재 실제엣지 계산.

    실제엣지 = (해외선물 bid / 국내현물 ask_usdt - 1) * 100 - BTC기준괴리
    """
    try:
        coin = core.normalize_symbol(pos.get("coin") or "")
        domestic = str(pos.get("domestic") or "").upper()
        foreign = str(pos.get("foreign") or "").upper()
        if not coin or not domestic or not foreign:
            return False, 0.0, "coin/domestic/foreign 누락"

        usd_krw = core.safe_float(pos.get("usd_krw"), 0.0)
        if usd_krw <= 1000:
            usd_krw = core.fetch_usd_krw()
        if usd_krw <= 1000:
            usd_krw = core.FALLBACK_USD_KRW

        # 국내 현물 현재 ask
        signal_like = dict(pos)
        signal_like.setdefault("domestic_market", "KRW-" + coin if domestic == "UPBIT" else coin + "_KRW")
        spot = core.fetch_current_domestic_book_for_signal(signal_like)
        if not spot:
            return False, 0.0, f"국내 현물 호가 조회 실패 {domestic} {coin}"
        spot_ask = core.safe_float(spot.get("best_ask"))
        spot_ask_usdt = spot_ask / usd_krw
        if spot_ask_usdt <= 0:
            return False, 0.0, "국내 현물 ask_usdt 계산 실패"

        # 해외 선물 현재 bid
        fex = core.GLOBAL_FUTURE_EXS.get(foreign)
        if not fex:
            return False, 0.0, f"해외 선물 객체 없음 {foreign}"
        future_market = pos.get("foreign_market") or core.find_future_market(fex, coin)
        if not future_market:
            return False, 0.0, f"해외 선물 마켓 없음 {foreign} {coin}"
        future = core.fetch_ccxt_book(fex, future_market, is_future=True)
        if not future:
            return False, 0.0, f"해외 선물 호가 조회 실패 {foreign} {future_market}"
        basis_now = core.calc_basis_percent(core.safe_float(future.get("best_bid")), spot_ask_usdt)

        # BTC 기준괴리 현재 재계산. 실패하면 포지션 저장값 fallback.
        btc_basis_now = core.safe_float(pos.get("btc_gap"), 0.0)
        btc_spot = core.fetch_current_btc_spot_for_source(domestic)
        if btc_spot:
            btc_market = core.find_future_market(fex, "BTC")
            btc_future = core.fetch_ccxt_book(fex, btc_market, is_future=True) if btc_market else None
            if btc_future:
                btc_spot_ask_usdt = core.safe_float(btc_spot.get("best_ask")) / usd_krw
                btc_basis_now = core.calc_basis_percent(core.safe_float(btc_future.get("best_bid")), btc_spot_ask_usdt)

        edge_now = basis_now - btc_basis_now
        detail = (
            f"basis={basis_now:+.2f}% btc={btc_basis_now:+.2f}% edge={edge_now:+.2f}% "
            f"spot_ask={spot_ask} future_bid={core.safe_float(future.get('best_bid'))} usdkrw={usd_krw:.2f}"
        )
        return True, edge_now, detail
    except Exception as e:
        return False, 0.0, f"현재엣지 계산 예외: {e}"


def handle_close_result(pos: Dict[str, Any], current_edge: float, ok: bool, detail: str) -> None:
    pos_id = str(pos.get("pos_id") or "")
    if ok:
        mark_position_closed_in_own_file(pos, "AUTO_CLOSED", current_edge, detail)
        print(f"[CLOSE SUCCESS DETAIL] {detail}")
        send_position_dm(
            pos,
            "✅ 자동익절 완료",
            "실거래 동시청산 성공\n✅ 해외 숏 청산 완료\n✅ 국내 현물 매도 완료",
            current_edge,
        )
        return

    # 실패/부분청산 상태 저장. CLOSED 처리 금지.
    fields = {
        "last_close_failed_at": core.now_str(),
        "last_close_failed_edge": round(float(current_edge), 4),
        "last_close_failed_detail": str(detail),
    }
    if "상태제안: FUTURES_CLOSED_ONLY" in str(detail):
        fields.update({"status": "FUTURES_CLOSED_ONLY", "futures_closed": True, "spot_closed": False})
    elif "상태제안: SPOT_CLOSED_ONLY" in str(detail):
        fields.update({"status": "SPOT_CLOSED_ONLY", "spot_closed": True, "futures_closed": False})
    else:
        fields.update({"status": str(pos.get("status") or "ACTIVE")})
    update_position_in_own_state_file(pos, fields)

    # 실패 DM 도배 방지: 같은 포지션 실패 알림은 기본 5분에 1회만 전송.
    now_ts = time.time()
    last_dm = float(_LAST_FAIL_DM_AT.get(pos_id, 0.0))
    if now_ts - last_dm >= FAIL_DM_COOLDOWN_SEC:
        _LAST_FAIL_DM_AT[pos_id] = now_ts
        send_position_dm(
            pos,
            "🚨 자동익절 청산 실패 - CLOSED 금지",
            "둘 다 성공하지 못해 포지션을 닫지 않았습니다. 다음 루프에서 재시도합니다.\n\n"
            "요약: 해외 청산 실패로 국내 매도 금지\n"
            "상세 오류는 콘솔 로그를 확인하세요.",
            current_edge,
        )
    else:
        remain = FAIL_DM_COOLDOWN_SEC - (now_ts - last_dm)
        print(f"[CLOSE FAIL DM SKIP] pos={pos_id} remain={remain:.1f}s")
    print(f"[CLOSE FAIL] pos={pos_id} detail={str(detail)[:500]}")


def should_attempt_close(pos: Dict[str, Any], current_edge: float) -> Tuple[bool, str]:
    status = str(pos.get("status") or "ACTIVE").upper()
    # 부분청산 상태는 엣지와 무관하게 남은 쪽 재시도 필요
    if status in {"FUTURES_CLOSED_ONLY", "SPOT_CLOSED_ONLY"}:
        return True, f"partial retry status={status}"

    take_profit_edge = core.safe_float(pos.get("take_profit_edge"), core.AUTO_TAKE_PROFIT_EDGE_PERCENT)
    trigger_max_edge = core.safe_float(pos.get("tp_trigger_close_max_edge"), TP_TRIGGER_CLOSE_MAX_EDGE)

    # 0.3 최초 도달 후에는 TP_TRIGGER를 저장한다.
    # 이후 엣지가 0.3 위로 튀어도 0.5 이하 구간이면 청산 재시도 유지.
    tp_triggered = bool(pos.get("tp_triggered"))
    if not tp_triggered and current_edge <= take_profit_edge:
        update_position_in_own_state_file(pos, {
            "tp_triggered": True,
            "tp_triggered_at": core.now_str(),
            "tp_trigger_edge": round(float(current_edge), 4),
            "tp_trigger_close_max_edge": trigger_max_edge,
        })
        pos["tp_triggered"] = True
        tp_triggered = True
        return True, (
            f"TP_TRIGGER current={current_edge:+.2f}% <= target={take_profit_edge:+.2f}% "
            f"/ close_allowed_until={trigger_max_edge:+.2f}%"
        )

    if tp_triggered:
        if current_edge <= trigger_max_edge:
            return True, (
                f"TP_TRIGGERED retry current={current_edge:+.2f}% <= max={trigger_max_edge:+.2f}% "
                f"/ original_target={take_profit_edge:+.2f}%"
            )
        return False, (
            f"TP_TRIGGERED but wait current={current_edge:+.2f}% > max={trigger_max_edge:+.2f}% "
            f"/ original_target={take_profit_edge:+.2f}%"
        )

    return False, f"hold current={current_edge:+.2f}% > target={take_profit_edge:+.2f}%"


def monitor_once() -> None:
    positions = core.get_active_positions_all_files()
    print(f"[CLOSE WORKER] ACTIVE positions={len(positions)} / {core.now_str()}")
    for pos in positions[:MAX_POSITIONS_PRINT]:
        print(f" - {pos.get('coin')} {pos.get('domestic')}->{pos.get('foreign')} status={pos.get('status')} pos={pos.get('pos_id')}")

    for pos in positions:
        pos_id = str(pos.get("pos_id") or "")
        if not pos_id:
            continue
        if pos_id in _CLOSING_POS_IDS:
            continue

        ok_edge, edge_now, edge_detail = compute_current_edge(pos)
        if not ok_edge:
            print(f"[CLOSE EDGE FAIL] {pos.get('coin')} {pos.get('domestic')}->{pos.get('foreign')} / {edge_detail}")
            continue

        do_close, why = should_attempt_close(pos, edge_now)
        print(f"[CLOSE CHECK] {pos.get('coin')} {pos.get('domestic')}->{pos.get('foreign')} {edge_now:+.2f}% / {why} / {edge_detail}")
        if not do_close:
            continue

        now_ts = time.time()
        last_try = float(_LAST_CLOSE_ATTEMPT_AT.get(pos_id, 0.0))
        if now_ts - last_try < CLOSE_RETRY_SEC:
            print(f"[CLOSE RETRY WAIT] {pos.get('coin')} pos={pos_id} remain={CLOSE_RETRY_SEC - (now_ts - last_try):.1f}s")
            continue

        _LAST_CLOSE_ATTEMPT_AT[pos_id] = now_ts
        _CLOSING_POS_IDS.add(pos_id)
        try:
            print(f"[CLOSE TRIGGER] {pos.get('coin')} {pos.get('domestic')}->{pos.get('foreign')} edge={edge_now:+.2f}% pos={pos_id}")
            if DRY_RUN:
                handle_close_result(pos, edge_now, False, "DRY_RUN=true: 실제 청산 주문 미전송")
            else:
                close_ok, close_detail = core.execute_auto_close_orders(pos, edge_now)
                handle_close_result(pos, edge_now, close_ok, close_detail)
        except Exception as e:
            detail = f"청산 처리 예외: {e}"
            print(f"[CLOSE ERROR] {detail}")
            traceback.print_exc()
            update_position_in_own_state_file(pos, {
                "last_close_failed_at": core.now_str(),
                "last_close_failed_edge": round(float(edge_now), 4),
                "last_close_failed_detail": detail,
            })
        finally:
            _CLOSING_POS_IDS.discard(pos_id)


def main() -> None:
    print("=" * 70)
    print("K-EDGE V9.5.2 CLOSE WORKER - REAL 0.3% TAKE PROFIT")
    print(f"POLL_SEC={POLL_SEC} / CLOSE_RETRY_SEC={CLOSE_RETRY_SEC} / DRY_RUN={DRY_RUN}")
    print(f"REAL_ORDER_ENABLED={getattr(core, 'REAL_ORDER_ENABLED', None)} / AUTO_TAKE_PROFIT_EDGE={getattr(core, 'AUTO_TAKE_PROFIT_EDGE_PERCENT', None)} / TP_TRIGGER_CLOSE_MAX_EDGE={TP_TRIGGER_CLOSE_MAX_EDGE}")
    print("Stop: Ctrl+C")
    print("=" * 70)
    while True:
        try:
            monitor_once()
        except KeyboardInterrupt:
            raise
        except Exception as e:
            print("[CLOSE WORKER LOOP ERROR]", e)
            traceback.print_exc()
        time.sleep(POLL_SEC)


if __name__ == "__main__":
    main()
