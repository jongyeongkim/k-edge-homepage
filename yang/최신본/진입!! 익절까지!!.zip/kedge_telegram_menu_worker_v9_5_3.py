# -*- coding: utf-8 -*-
"""
K-EDGE V9.5.3d TELEGRAM MENU WORKER

핵심:
- @Kedge0203bot 토큰 자동 선택
- /start, 메뉴 입력 시 하단 고정 버튼(reply_keyboard) 전송
- 📊 포지션조회 / 📈 통계조회 / 🛑 자동정지 / ▶ 자동시작
- 조회/통계는 읽기 전용
"""

import os
import json
import time
import glob
import traceback
import importlib.util
from pathlib import Path

try:
    import requests
except Exception:
    requests = None


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TARGET_BOT_USERNAME = os.environ.get("KEDGE_MENU_BOT_USERNAME", "Kedge0203bot").strip().lstrip("@")
OFFSET_PATH = os.path.join(BASE_DIR, "telegram_menu_worker.offset")
MENU_LOG_PREFIX = "[MENU WORKER]"


def load_core():
    candidates = []
    candidates += sorted(glob.glob(os.path.join(BASE_DIR, "kedge_v9_5_2_SCAN_QUEUE_MEXC.py")))
    candidates += sorted(glob.glob(os.path.join(BASE_DIR, "kedge*_SCAN_QUEUE_MEXC.py")))
    candidates += sorted(glob.glob(os.path.join(BASE_DIR, "kedge*_MEXC*.py")))
    seen = []
    for p in candidates:
        if p not in seen:
            seen.append(p)
    if not seen:
        print("[치명] core MEXC 파일을 찾을 수 없습니다.")
        return None

    target = seen[-1]
    try:
        spec = importlib.util.spec_from_file_location("kedge_core", target)
        core = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(core)
        print(f"{MENU_LOG_PREFIX} core loaded: {os.path.basename(target)}")
        return core
    except Exception as e:
        print("[치명] core 로드 실패:", e)
        traceback.print_exc()
        return None


core = load_core()


def looks_like_bot_token(s):
    if not isinstance(s, str):
        return False
    s = s.strip()
    if len(s) < 30 or ":" not in s:
        return False
    left, right = s.split(":", 1)
    return left.isdigit() and len(right) >= 20


def collect_token_candidates():
    tokens = []

    for name in [
        "KEDGE_COMMON_BOT_TOKEN",
        "KEDGE_MENU_BOT_TOKEN",
        "COMMON_TELEGRAM_BOT_TOKEN",
        "COMMON_BOT_TOKEN",
        "KEDGE_BOT_TOKEN",
    ]:
        val = os.environ.get(name, "").strip()
        if looks_like_bot_token(val):
            tokens.append((name, val))

    for fname in [
        "kedge_common_bot_token.txt",
        "kedge_menu_bot_token.txt",
        "common_bot_token.txt",
    ]:
        p = os.path.join(BASE_DIR, fname)
        if os.path.exists(p):
            try:
                val = Path(p).read_text(encoding="utf-8").strip()
                if looks_like_bot_token(val):
                    tokens.append((fname, val))
            except Exception:
                pass

    if core:
        priority_names = [
            "COMMON_TELEGRAM_BOT_TOKEN",
            "COMMON_BOT_TOKEN",
            "KEDGE_COMMON_BOT_TOKEN",
            "KEDGE_COMMON_BOT_TOKEN_DEFAULT",
            "KEDGE_BOT_TOKEN",
            "AUTO_COMMON_BOT_TOKEN",
            "TELEGRAM_COMMON_BOT_TOKEN",
        ]

        for name in priority_names:
            val = getattr(core, name, None)
            if looks_like_bot_token(val):
                tokens.append((f"core.{name}", val.strip()))

        for name in dir(core):
            if name.startswith("__"):
                continue
            try:
                val = getattr(core, name)
            except Exception:
                continue
            if looks_like_bot_token(val):
                tokens.append((f"core.{name}", val.strip()))

    dedup = []
    seen = set()
    for src, tok in tokens:
        if tok not in seen:
            seen.add(tok)
            dedup.append((src, tok))
    return dedup


def test_token(token):
    if requests is None:
        raise RuntimeError("requests 모듈이 없습니다. pip install requests 필요")
    url = f"https://api.telegram.org/bot{token}/getMe"
    r = requests.post(url, json={}, timeout=10)
    try:
        data = r.json()
    except Exception:
        data = {"ok": False, "raw": r.text}
    return r.status_code, data


def select_bot_token():
    candidates = collect_token_candidates()
    print(f"{MENU_LOG_PREFIX} token candidates={len(candidates)} / target=@{TARGET_BOT_USERNAME}")

    fallback = None

    for src, tok in candidates:
        masked = tok[:10] + "..." + tok[-6:]
        try:
            code, data = test_token(tok)
            username = ((data.get("result") or {}).get("username") or "")
            ok = data.get("ok")
            print(f"{MENU_LOG_PREFIX} token test src={src} token={masked} ok={ok} username=@{username}")
            if ok and username == TARGET_BOT_USERNAME:
                print(f"{MENU_LOG_PREFIX} SELECTED BOT @{TARGET_BOT_USERNAME} from {src}")
                return tok
            if ok and fallback is None:
                fallback = (src, tok, data)
        except Exception as e:
            print(f"{MENU_LOG_PREFIX} token test fail src={src} token={masked} err={e}")

    print("")
    print("[치명] @Kedge0203bot 토큰을 찾지 못했습니다.")
    print("해결방법: yang 폴더에 kedge_common_bot_token.txt 파일을 만들고 @Kedge0203bot 토큰 전체를 첫 줄에 넣으세요.")
    if fallback:
        src, tok, data = fallback
        uname = ((data.get("result") or {}).get("username") or "")
        print(f"[참고] 찾은 봇은 @{uname} 입니다. 목표 봇이 아닙니다: {src}")
    raise SystemExit(1)


BOT_TOKEN = select_bot_token()


def tg_api(method, payload=None, timeout=15):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/{method}"
    r = requests.post(url, json=payload or {}, timeout=timeout)
    try:
        return r.status_code, r.json()
    except Exception:
        return r.status_code, {"raw": r.text}


def reply_keyboard_markup():
    return {
        "keyboard": [
            [
                {"text": "📊 포지션조회"},
                {"text": "📈 통계조회"},
            ],
            [
                {"text": "🛑 자동정지"},
                {"text": "▶ 자동시작"},
            ],
        ],
        "resize_keyboard": True,
        "one_time_keyboard": False,
        "is_persistent": True,
        "input_field_placeholder": "K-EDGE 메뉴를 선택하세요",
    }


def send_message(chat_id, text, reply_markup=None):
    payload = {
        "chat_id": str(chat_id),
        "text": text,
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }
    if reply_markup:
        payload["reply_markup"] = reply_markup
    code, data = tg_api("sendMessage", payload)
    print(f"{MENU_LOG_PREFIX} sendMessage chat={chat_id} code={code} ok={data.get('ok')}")
    if not data.get("ok"):
        print(f"{MENU_LOG_PREFIX} sendMessage error={data}")
    return data


def send_main_menu(chat_id):
    text = (
        "🤖 <b>K-EDGE AUTO 메뉴</b>\n\n"
        "아래 고정 버튼에서 원하는 기능을 선택하세요.\n\n"
        "📊 포지션조회: 현재 보유 포지션 확인\n"
        "📈 통계조회: 누적/일별 통계 확인\n"
        "🛑 자동정지: 신규 자동진입 정지\n"
        "▶ 자동시작: 자동진입 재시작\n\n"
        "※ 조회 기능은 읽기 전용이며 주문/청산을 실행하지 않습니다."
    )
    return send_message(chat_id, text, reply_keyboard_markup())


def safe_float(v, default=0.0):
    try:
        if v is None or v == "":
            return default
        return float(v)
    except Exception:
        return default


def fmt_krw(v):
    v = safe_float(v)
    if abs(v) >= 100000000:
        return f"{v/100000000:.2f}억"
    if abs(v) >= 10000:
        return f"{v/10000:.1f}만"
    return f"{v:,.0f}원"


def load_state_files():
    paths = []
    for name in [
        "semi_auto_state_mexc.json",
        "semi_auto_state_gate.json",
        "semi_auto_state_bitget.json",
        "semi_auto_state_bingx.json",
    ]:
        p = os.path.join(BASE_DIR, name)
        if os.path.exists(p):
            paths.append(p)
    return paths


def extract_positions_for_chat(chat_id):
    chat_id = str(chat_id)
    results = []

    for path in load_state_files():
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            continue

        candidates = []
        if isinstance(data, dict):
            for key in ["active_positions", "positions", "paper_entries"]:
                val = data.get(key)
                if isinstance(val, list):
                    candidates.extend(val)
                elif isinstance(val, dict):
                    candidates.extend(val.values())

            for k, v in data.items():
                if isinstance(v, dict) and ("position_id" in v or "coin" in v or "symbol" in v):
                    candidates.append(v)
        elif isinstance(data, list):
            candidates = data

        for pos in candidates:
            if not isinstance(pos, dict):
                continue

            status = str(pos.get("status", "ACTIVE")).upper()
            if status not in ["ACTIVE", "OPEN", "DOMESTIC_ONLY", "FUTURES_ONLY"]:
                continue

            pos_chat = str(
                pos.get("tg_chat_id")
                or pos.get("chat_id")
                or pos.get("user_id")
                or pos.get("telegram_chat_id")
                or ""
            )
            if pos_chat and pos_chat != chat_id:
                continue
            if not pos_chat:
                continue

            pos["_state_file"] = os.path.basename(path)
            results.append(pos)

    return results



_MENU_FUTURE_EXS_CACHE = None


def _ensure_menu_future_exs():
    """포지션조회 현재엣지 계산용 선물 거래소 객체를 안전하게 준비한다."""
    global _MENU_FUTURE_EXS_CACHE
    if _MENU_FUTURE_EXS_CACHE:
        return _MENU_FUTURE_EXS_CACHE
    if not core:
        return {}
    try:
        existing = getattr(core, "GLOBAL_FUTURE_EXS", None)
        if isinstance(existing, dict) and existing:
            _MENU_FUTURE_EXS_CACHE = existing
            return _MENU_FUTURE_EXS_CACHE
    except Exception:
        pass
    try:
        if hasattr(core, "init_ccxt_all") and hasattr(core, "init_callback_future_exs"):
            old_flag = getattr(core, "ENABLE_CALLBACK_POLLER", None)
            try:
                core.ENABLE_CALLBACK_POLLER = True
            except Exception:
                pass
            _, future_exs = core.init_ccxt_all()
            _MENU_FUTURE_EXS_CACHE = core.init_callback_future_exs(future_exs)
            try:
                core.GLOBAL_FUTURE_EXS = _MENU_FUTURE_EXS_CACHE
            except Exception:
                pass
            try:
                if old_flag is not None:
                    core.ENABLE_CALLBACK_POLLER = old_flag
            except Exception:
                pass
            print(f"{MENU_LOG_PREFIX} current-edge futures={sorted((_MENU_FUTURE_EXS_CACHE or {}).keys())}")
            return _MENU_FUTURE_EXS_CACHE or {}
    except Exception as e:
        print(f"{MENU_LOG_PREFIX} current-edge futures init skipped: {e}")
    return {}


def _fmt_edge(v):
    try:
        if v is None or v == "":
            return "-"
        return f"{float(v):+.2f}%"
    except Exception:
        return str(v)


def calc_current_edge_for_position(pos):
    """현재 실제엣지 계산. 실패하면 None을 반환해서 조회 자체는 절대 깨지지 않게 한다."""
    if not core or not isinstance(pos, dict):
        return None
    try:
        coin = pos.get("coin") or pos.get("symbol") or pos.get("base") or ""
        domestic = (pos.get("domestic_exchange") or pos.get("domestic") or "BITHUMB")
        foreign = (pos.get("foreign_exchange") or pos.get("exchange") or pos.get("foreign") or "")
        if not coin or not foreign:
            return None
        signal = dict(pos)
        signal.setdefault("coin", coin)
        signal.setdefault("domestic", domestic)
        signal.setdefault("domestic_exchange", domestic)
        signal.setdefault("foreign", foreign)
        signal.setdefault("foreign_exchange", foreign)
        if not signal.get("domestic_market"):
            signal["domestic_market"] = f"{coin}_KRW"

        usd_krw = 0.0
        try:
            if hasattr(core, "fetch_usd_krw"):
                usd_krw = float(core.fetch_usd_krw())
        except Exception:
            usd_krw = 0.0
        if usd_krw <= 0:
            usd_krw = float(signal.get("usd_krw") or getattr(core, "FALLBACK_USD_KRW", 1509.0) or 1509.0)

        future_exs = _ensure_menu_future_exs()
        fex = future_exs.get(str(foreign).upper()) if isinstance(future_exs, dict) else None
        if not fex:
            return None

        spot = core.fetch_current_domestic_book_for_signal(signal)
        if not spot:
            return None
        spot_ask_usdt = float(spot.get("best_ask") or 0) / max(1.0, usd_krw)
        if spot_ask_usdt <= 0:
            return None

        market = signal.get("foreign_market") or core.find_future_market(fex, coin)
        if not market:
            return None
        future = core.fetch_ccxt_book(fex, market, is_future=True)
        if not future:
            return None
        basis_now = core.calc_basis_percent(float(future.get("best_bid") or 0), spot_ask_usdt)

        btc_basis_now = None
        try:
            btc_spot = core.fetch_current_btc_spot_for_source(str(domestic).upper())
            btc_market = core.find_future_market(fex, "BTC")
            btc_future = core.fetch_ccxt_book(fex, btc_market, is_future=True) if btc_market else None
            if btc_spot and btc_future:
                btc_spot_ask_usdt = float(btc_spot.get("best_ask") or 0) / max(1.0, usd_krw)
                if btc_spot_ask_usdt > 0:
                    btc_basis_now = core.calc_basis_percent(float(btc_future.get("best_bid") or 0), btc_spot_ask_usdt)
        except Exception:
            btc_basis_now = None
        if btc_basis_now is None:
            btc_basis_now = float(signal.get("btc_gap") or 0)
        return float(basis_now) - float(btc_basis_now)
    except Exception as e:
        try:
            c = pos.get("coin")
        except Exception:
            c = "-"
        print(f"{MENU_LOG_PREFIX} current-edge calc fail coin={c} err={e}")
        return None


def position_text(chat_id):
    positions = extract_positions_for_chat(chat_id)

    if not positions:
        return (
            "📊 <b>현재 보유 포지션</b>\n\n"
            "현재 조회되는 ACTIVE 포지션이 없습니다.\n\n"
            "※ 조회 시점 기준입니다."
        )

    lines = []
    lines.append("📊 <b>현재 보유 포지션</b>")
    lines.append("")
    lines.append(f"보유수: <b>{len(positions)}개</b>")
    lines.append("")

    for i, p in enumerate(positions, 1):
        coin = p.get("coin") or p.get("symbol") or p.get("base") or "-"
        domestic = p.get("domestic_exchange") or p.get("domestic") or "BITHUMB"
        foreign = p.get("foreign_exchange") or p.get("exchange") or p.get("foreign") or "-"
        entry_edge = p.get("entry_edge") or p.get("entry_real_edge") or p.get("real_edge") or p.get("entry_edge_percent")
        current_edge = calc_current_edge_for_position(p)
        domestic_krw = (
            p.get("domestic_entry_krw")
            or p.get("domestic_amount_krw")
            or p.get("entry_krw")
            or p.get("final_entry_krw")
            or p.get("amount_krw")
            or 0
        )
        foreign_krw = (
            p.get("foreign_entry_krw")
            or p.get("foreign_notional_krw")
            or p.get("foreign_amount_krw")
            or p.get("final_entry_krw")
            or 0
        )

        lines.append("━━━━━━━━━━━━━━")
        lines.append(f"{i}) 🟢 <b>{coin}</b>")
        lines.append(f"{domestic} ↔ {foreign}")
        lines.append("")
        lines.append(f"{_fmt_edge(entry_edge)} → {_fmt_edge(current_edge) if current_edge is not None else '조회불가'}")
        if domestic_krw or foreign_krw:
            lines.append("")
        if domestic_krw:
            lines.append(f"국내: {fmt_krw(domestic_krw)}")
        if foreign_krw:
            lines.append(f"해외숏: {fmt_krw(foreign_krw)}")

    lines.append("")
    lines.append("※ 현재엣지는 조회 시점 실시간 호가 기준이며, 실패 시 조회불가로 표시됩니다.")
    return "\n".join(lines)

def stats_text(chat_id):
    paths = [
        os.path.join(BASE_DIR, "paper_trading_data", "daily_stats.json"),
        os.path.join(BASE_DIR, "daily_stats.json"),
    ]

    stats = None
    for p in paths:
        if os.path.exists(p):
            try:
                with open(p, "r", encoding="utf-8") as f:
                    stats = json.load(f)
                break
            except Exception:
                pass

    positions = extract_positions_for_chat(chat_id)

    if not stats:
        return (
            "📈 <b>통계조회</b>\n\n"
            f"현재 보유 ACTIVE: <b>{len(positions)}개</b>\n\n"
            "아직 연결된 통계 파일을 찾지 못했습니다."
        )

    return (
        "📈 <b>통계조회</b>\n\n"
        f"현재 보유 ACTIVE: <b>{len(positions)}개</b>\n\n"
        f"<pre>{json.dumps(stats, ensure_ascii=False, indent=2)[:3000]}</pre>"
    )


def handle_stop(chat_id):
    return send_message(
        chat_id,
        "🛑 <b>자동정지 요청 접수</b>\n\n"
        "현재 V9.5.3d 메뉴 워커에서는 안전상 실제 정지 상태 변경은 아직 수행하지 않습니다.\n"
        "다음 패치에서 auto_settings running=false 저장과 연동합니다.",
        reply_keyboard_markup()
    )


def handle_start(chat_id):
    return send_message(
        chat_id,
        "▶ <b>자동시작 요청 접수</b>\n\n"
        "현재 V9.5.3d 메뉴 워커에서는 안전상 실제 시작 상태 변경은 아직 수행하지 않습니다.\n"
        "다음 패치에서 auto_settings running=true 저장과 연동합니다.",
        reply_keyboard_markup()
    )


def read_offset():
    try:
        if os.path.exists(OFFSET_PATH):
            return int(Path(OFFSET_PATH).read_text(encoding="utf-8").strip() or "0")
    except Exception:
        pass
    return 0


def write_offset(offset):
    try:
        Path(OFFSET_PATH).write_text(str(offset), encoding="utf-8")
    except Exception:
        pass


def poll_loop():
    print("=" * 70)
    print("K-EDGE V9.5.3d TELEGRAM MENU WORKER")
    print(f"Target bot: @{TARGET_BOT_USERNAME}")
    print("Keyboard: persistent reply keyboard")
    print("Buttons: 📊 포지션조회 / 📈 통계조회 / 🛑 자동정지 / ▶ 자동시작")
    print("Safe: read-only lookup, no order, no close")
    print("Start: send /start or 메뉴 to @Kedge0203bot DM")
    print("Stop: Ctrl+C")
    print("=" * 70)

    try:
        code, me = tg_api("getMe", {})
        print("[BOT]", me)
    except Exception as e:
        print("[BOT ERROR]", e)
        return

    offset = read_offset()

    while True:
        try:
            code, data = tg_api("getUpdates", {
                "offset": offset + 1 if offset else 0,
                "timeout": 25,
                "allowed_updates": ["message"]
            }, timeout=35)

            if not data.get("ok"):
                print("[getUpdates fail]", code, data)
                time.sleep(3)
                continue

            for upd in data.get("result", []):
                offset = max(offset, int(upd.get("update_id", 0)))
                write_offset(offset)

                if "message" not in upd:
                    continue

                msg = upd["message"]
                chat_id = msg.get("chat", {}).get("id")
                text = (msg.get("text") or "").strip()
                print(f"[MESSAGE] chat={chat_id} text={text}")

                if text in ["/start", "start", "시작", "메뉴", "/menu"]:
                    send_main_menu(chat_id)
                elif text in ["📊 포지션조회", "조회", "포지션", "내포지션", "/positions", "/position"]:
                    send_message(chat_id, position_text(chat_id), reply_keyboard_markup())
                elif text in ["📈 통계조회", "통계", "/stats", "통계조회"]:
                    send_message(chat_id, stats_text(chat_id), reply_keyboard_markup())
                elif text in ["🛑 자동정지", "자동정지", "정지", "/stop"]:
                    handle_stop(chat_id)
                elif text in ["▶ 자동시작", "자동시작", "시작", "/start_auto"]:
                    handle_start(chat_id)
                else:
                    send_main_menu(chat_id)

        except KeyboardInterrupt:
            print("Stopped.")
            break
        except Exception as e:
            print("[LOOP ERROR]", e)
            traceback.print_exc()
            time.sleep(3)


if __name__ == "__main__":
    poll_loop()
