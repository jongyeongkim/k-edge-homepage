@echo off
chcp 65001 > nul
cd /d "%~dp0"
title K-EDGE V9.5.1 QUEUE ARCH

echo ========================================
echo K-EDGE V9.5.1 QUEUE ARCH
echo Scanner 4 + Order Worker + Close Worker
echo ========================================

start "KEDGE_SCAN_MEXC" cmd /k py kedge_v9_5_1_SCAN_QUEUE_MEXC.py
start "KEDGE_SCAN_GATE" cmd /k py kedge_v9_5_1_SCAN_QUEUE_GATE.py
start "KEDGE_SCAN_BITGET" cmd /k py kedge_v9_5_1_SCAN_QUEUE_BITGET.py
start "KEDGE_SCAN_BINGX" cmd /k py kedge_v9_5_1_SCAN_QUEUE_BINGX.py
start "KEDGE_ORDER_WORKER" cmd /k py kedge_order_worker_v9_5_1.py
start "KEDGE_CLOSE_WORKER" cmd /k py kedge_close_worker_v9_5_1.py

echo Started.
pause
