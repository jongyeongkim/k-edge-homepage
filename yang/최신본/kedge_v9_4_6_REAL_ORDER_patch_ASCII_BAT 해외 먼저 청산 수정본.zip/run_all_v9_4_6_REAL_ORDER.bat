@echo off
cd /d "%~dp0"

title K-EDGE V9.4.6 REAL ORDER AUTO - ALL

set MAX_AUTO_RECHECK_DELAY_SEC=1.0
set MIN_ALLOWED_SLIPPAGE_FOR_REAL_ENTRY_PERCENT=0.15

echo K-EDGE V9.4.6 REAL ORDER START
echo Foreign-first ENTRY/CLOSE patch
echo Speed guard: recheck <= 1.0 sec
echo Slippage guard: min 0.15 percent
echo.

start "KEDGE MEXC REAL" cmd /k "%~dp0run_mexc_v9_4_6.bat"
timeout /t 1 >nul
start "KEDGE GATE REAL" cmd /k "%~dp0run_gate_v9_4_6.bat"
timeout /t 1 >nul
start "KEDGE BITGET REAL" cmd /k "%~dp0run_bitget_v9_4_6.bat"
timeout /t 1 >nul
start "KEDGE BINGX REAL" cmd /k "%~dp0run_bingx_v9_4_6.bat"

echo.
echo All 4 exchange bots launched.
echo Check each command window.
pause
