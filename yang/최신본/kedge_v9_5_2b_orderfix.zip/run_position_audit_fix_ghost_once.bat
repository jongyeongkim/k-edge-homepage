@echo off
chcp 65001 > nul
cd /d "%~dp0"
title K-EDGE POSITION AUDIT AUTO FIX GHOST ONLY
set POSITION_AUDIT_AUTO_FIX=true
set POSITION_AUDIT_FIX_GHOST_ONLY=true
set POSITION_CHECK_LOOP=false
set POSITION_CHECK_DUST_KRW=1000
py kedge_position_audit_worker_v9_5_2.py
pause
