@echo off
chcp 65001 > nul
cd /d "%~dp0"
title K-EDGE V9.5.2 SPEED AUDIT

echo ========================================
echo K-EDGE V9.5.2 SPEED AUDIT
echo Scanner 4 + Order Worker + Close Worker + Position Audit
echo ========================================

REM MEXC 510 mitigation defaults
set MEXC_MAX_SPOT_ITEMS=45
set MEXC_MAX_BITHUMB_ITEMS=45
set MEXC_FAST_SCAN_WORKERS=1
set MEXC_REQUEST_INTERVAL_SEC=0.32
set MEXC_RATE_LIMIT_COOLDOWN_SEC=6
set ORDER_MEMBER_CACHE_TTL_SEC=120

REM Position audit default: dry-run only. Set true manually after checking logs.
set POSITION_AUDIT_AUTO_FIX=false
set POSITION_AUDIT_FIX_GHOST_ONLY=true
set POSITION_CHECK_LOOP=true
set POSITION_CHECK_INTERVAL_SEC=300
set POSITION_CHECK_DUST_KRW=1000

start "KEDGE_SCAN_MEXC" cmd /k py kedge_v9_5_2_SCAN_QUEUE_MEXC.py
start "KEDGE_SCAN_GATE" cmd /k py kedge_v9_5_2_SCAN_QUEUE_GATE.py
start "KEDGE_SCAN_BITGET" cmd /k py kedge_v9_5_2_SCAN_QUEUE_BITGET.py
start "KEDGE_SCAN_BINGX" cmd /k py kedge_v9_5_2_SCAN_QUEUE_BINGX.py
start "KEDGE_ORDER_WORKER" cmd /k py kedge_order_worker_v9_5_2.py
start "KEDGE_CLOSE_WORKER" cmd /k py kedge_close_worker_v9_5_2.py
start "KEDGE_POSITION_AUDIT" cmd /k py kedge_position_audit_worker_v9_5_2.py

echo Started.
pause
