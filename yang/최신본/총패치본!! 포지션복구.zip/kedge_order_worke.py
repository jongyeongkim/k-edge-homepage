# -*- coding: utf-8 -*-
"""
K-EDGE V9.5.2b ORDER WORKER
- Reads order_queue.jsonl written by the 4 scanner bots.
- Performs member lookup, duplicate ACTIVE lock, final recheck, foreign short first, Bithumb buy second.
- Scanner bots must be scanner-only and must not place orders.
"""
import os
import sys
import json
import time
import glob
import importlib.util
import traceback
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, Set, Tuple, List

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ORDER_QUEUE_PATH = os.path.join(BASE_DIR, "order_queue.jsonl")
ORDER_QUEUE_OFFSET_PATH = os.path.join(BASE_DIR, "order_queue.offset")
ORDER_WORKER_PROCESSED_PATH = os.path.join(BASE_DIR, "order_worker_processed.json")
ORDER_WORKER_POLL_SEC = float(os.getenv("ORDER_WORKER_POLL_SEC", "0.2"))
QUEUE_ITEM_MAX_AGE_SEC = int(os.getenv("QUEUE_ITEM_MAX_AGE_SEC", "30"))
ORDER_WORKER_MAX_PARALLEL = int(os.getenv("ORDER_WORKER_MAX_PARALLEL", "10"))

_PRINT_LOCK = threading.Lock()

def log(msg: str) -> None:
    """Thread-safe print for parallel order logs."""
    with _PRINT_LOCK:
        print(msg, flush=True)

ORDER_MEMBER_CACHE_TTL_SEC = int(os.getenv("ORDER_MEMBER_CACHE_TTL_SEC", "120"))
_ORDER_MEMBER_CACHE = {"ts": 0.0, "members": None}

def get_approved_members_cached():
    """ORDER WORKER 전용 승인회원 캐시.
    V9.5.2b: 자기 자신을 다시 호출하던 재귀 버그 수정.
    실제 조회는 core.supabase_get_approved_members(force_refresh=True)를 사용한다.
    """
    now = time.time()
    if _ORDER_MEMBER_CACHE.get("members") is not None and now - float(_ORDER_MEMBER_CACHE.get("ts") or 0) < ORDER_MEMBER_CACHE_TTL_SEC:
        return _ORDER_MEMBER_CACHE["members"]

    try:
        if hasattr(core, "supabase_get_approved_members"):
            members = core.supabase_get_approved_members(force_refresh=True)
        elif hasattr(core, "supabase_get_approved_members_uncached"):
            members = core.supabase_get_approved_members_uncached()
        else:
            print("[ORDER MEMBER CACHE] core 승인회원 조회 함수 없음")
            members = []
    except Exception as e:
        print(f"[ORDER MEMBER CACHE] 승인회원 조회 실패: {e}")
        members = []

    _ORDER_MEMBER_CACHE["members"] = members
    _ORDER_MEMBER_CACHE["ts"] = now
    return members



def load_core():
    candidates = sorted(glob.glob(os.path.join(BASE_DIR, "kedge_v9_5_2_SCAN_QUEUE_MEXC.py")))
    if not candidates:
        candidates = sorted(glob.glob(os.path.join(BASE_DIR, "kedge*_MEXC*.py")))
    if not candidates:
        print("[FATAL] MEXC core file not found")
        sys.exit(1)
    target = candidates[-1]
    spec = importlib.util.spec_from_file_location("kedge_core_order", target)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    print(f"[ORDER WORKER] core loaded: {os.path.basename(target)}")
    return module


core = load_core()

# Workers, unlike scanner files, must have full futures objects for recheck/order.
# Scanner files keep ENABLE_CALLBACK_POLLER=False, but workers need MEXC/GATE/BITGET/BINGX loaded.
try:
    core.ENABLE_CALLBACK_POLLER = True
    _, future_exs = core.init_ccxt_all()
    core.GLOBAL_FUTURE_EXS = core.init_callback_future_exs(future_exs)
    print(f"[ORDER WORKER] GLOBAL_FUTURE_EXS={sorted(core.GLOBAL_FUTURE_EXS.keys())}")
except Exception as e:
    print(f"[ORDER WORKER] futures init warning: {e}")


def read_json(path: str, default: Any) -> Any:
    try:
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return default


def write_json(path: str, data: Any) -> None:
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def _norm_exchange(v: Any) -> str:
    return str(v or "").strip().upper()


def _norm_coin(v: Any) -> str:
    return str(v or "").strip().upper().replace("_KRW", "").replace("/USDT:USDT", "").replace("/USDT", "")


def _state_files_for_lock() -> List[str]:
    """중복진입 LOCK용 state 파일 탐색.
    주문 전 확인만 수행하며 파일을 수정하지 않는다.
    """
    names = [
        "semi_auto_state_mexc.json",
        "semi_auto_state_gate.json",
        "semi_auto_state_bitget.json",
        "semi_auto_state_bingx.json",
    ]
    paths = []
    for name in names:
        p = os.path.join(BASE_DIR, name)
        if os.path.exists(p):
            paths.append(p)
    for p in sorted(glob.glob(os.path.join(BASE_DIR, "semi_auto_state_*.json"))):
        if p not in paths:
            paths.append(p)
    return paths


def _iter_active_positions_for_lock() -> List[Dict[str, Any]]:
    """현재 state 안의 ACTIVE/OPEN 포지션 전체를 읽는다."""
    out: List[Dict[str, Any]] = []
    for path in _state_files_for_lock():
        try:
            data = read_json(path, {})
            positions = data.get("positions") if isinstance(data, dict) else {}
            if isinstance(positions, dict):
                vals = positions.values()
            elif isinstance(positions, list):
                vals = positions
            else:
                vals = []
            for pos in vals:
                if not isinstance(pos, dict):
                    continue
                status = str(pos.get("status") or "").upper()
                if status not in ("ACTIVE", "OPEN", "REAL_OPEN", "VIRTUAL_OPEN", "DOMESTIC_ONLY", "FUTURES_ONLY", "FUTURES_CLOSED_ONLY", "SPOT_CLOSED_ONLY"):
                    continue
                out.append(pos)
        except Exception as e:
            log(f"[ORDER ACTIVE LOCK WARN] read state failed {os.path.basename(path)} / {e}")
    return out


def has_duplicate_active_position(member: Dict[str, Any], signal: Dict[str, Any]) -> Tuple[bool, str]:
    """유저별 같은 코인 + 같은 해외거래소 ACTIVE 중복 진입 차단.
    같은 코인이라도 해외거래소가 다르면 허용한다.
    """
    target_coin = _norm_coin(signal.get("coin") or signal.get("symbol"))
    target_foreign = _norm_exchange(signal.get("foreign") or signal.get("foreign_exchange") or signal.get("exchange"))
    target_user = str(core.get_member_chat_id(member) or member.get("tg_chat_id") or member.get("chat_id") or member.get("user_id") or "").strip()

    if not target_coin or not target_foreign or not target_user:
        return False, ""

    for pos in _iter_active_positions_for_lock():
        pos_coin = _norm_coin(pos.get("coin") or pos.get("symbol"))
        pos_foreign = _norm_exchange(pos.get("foreign") or pos.get("foreign_exchange") or pos.get("exchange"))
        pos_user = str(pos.get("user_id") or pos.get("tg_chat_id") or pos.get("chat_id") or pos.get("telegram_chat_id") or "").strip()

        if pos_coin == target_coin and pos_foreign == target_foreign and pos_user == target_user:
            pos_id = pos.get("pos_id") or pos.get("position_id") or pos.get("id") or ""
            return True, f"{target_coin} {target_foreign} ACTIVE already exists pos_id={pos_id}"

    return False, ""


def get_offset() -> int:
    try:
        if os.path.exists(ORDER_QUEUE_OFFSET_PATH):
            return int(open(ORDER_QUEUE_OFFSET_PATH, "r", encoding="utf-8").read().strip() or "0")
    except Exception:
        pass
    return 0


def set_offset(offset: int) -> None:
    with open(ORDER_QUEUE_OFFSET_PATH, "w", encoding="utf-8") as f:
        f.write(str(int(offset)))


def load_processed() -> Set[str]:
    data = read_json(ORDER_WORKER_PROCESSED_PATH, {})
    if isinstance(data, dict):
        return set(str(k) for k in data.keys())
    return set()


def mark_processed(signal_id: str, result: str) -> None:
    data = read_json(ORDER_WORKER_PROCESSED_PATH, {})
    if not isinstance(data, dict):
        data = {}
    data[str(signal_id)] = {"at": core.now_str(), "result": result}
    # keep size bounded
    if len(data) > 2000:
        for k in list(data.keys())[:500]:
            data.pop(k, None)
    write_json(ORDER_WORKER_PROCESSED_PATH, data)


def build_order_member(raw_member: Dict[str, Any], seen: Set[str]) -> Tuple[str, Dict[str, Any], str]:
    """Validate and normalize one approved member before parallel order execution."""
    raw_tg = str(core.get_member_chat_id(raw_member) or "").strip()
    member = core.merge_member_auto_settings(raw_member)
    tg_id = raw_tg or str(core.get_member_chat_id(member) or "").strip()

    if raw_tg and not str(member.get("tg_chat_id") or member.get("chat_id") or "").strip():
        member["tg_chat_id"] = raw_tg

    if not tg_id:
        return "", member, "missing tg_id"
    if tg_id in seen:
        return "", member, "duplicate tg_id"
    seen.add(tg_id)

    if not core.is_member_service_enabled(member):
        return "", member, "service off"
    if not core.is_member_auto_enabled(member):
        return "", member, "auto off"

    return tg_id, member, ""


def run_member_entry(member: Dict[str, Any], signal: Dict[str, Any], tg_id: str) -> Tuple[str, bool, str]:
    """Run one member order. Exception is converted to fail result so worker keeps running."""
    try:
        dup, reason = has_duplicate_active_position(member, signal)
        if dup:
            return tg_id, False, "[DUPLICATE ACTIVE LOCK] " + reason

        ok, detail = core.perform_auto_entry_for_member(member, signal)
        return tg_id, bool(ok), str(detail)
    except Exception as e:
        return tg_id, False, "EXCEPTION: " + repr(e) + "\n" + traceback.format_exc()


def process_signal(signal: Dict[str, Any]) -> None:
    signal_id = str(signal.get("signal_id") or "")
    if not signal_id:
        log("[ORDER SKIP] signal_id missing")
        return

    members = get_approved_members_cached()
    if not members:
        log("[ORDER SKIP] approved members empty")
        return

    seen: Set[str] = set()
    eligible: List[Tuple[str, Dict[str, Any]]] = []
    skipped = 0

    # Member filtering is still sequential and cheap. Actual order execution is parallel below.
    for raw_member in members:
        tg_id, member, reason = build_order_member(raw_member, seen)
        if not tg_id:
            skipped += 1
            if reason not in ("duplicate tg_id", "missing tg_id"):
                log(f"[ORDER SKIP] {reason} tg={str(core.get_member_chat_id(raw_member) or '').strip()}")
            continue
        eligible.append((tg_id, member))

    if not eligible:
        log(f"[ORDER RESULT] {signal.get('coin')} {signal.get('domestic')}->{signal.get('foreign')} eligible=0 skipped={skipped}")
        return

    max_workers = max(1, min(ORDER_WORKER_MAX_PARALLEL, len(eligible)))
    log(f"[ORDER PARALLEL START] {signal.get('coin')} {signal.get('domestic')}->{signal.get('foreign')} users={len(eligible)} workers={max_workers}")

    ok_count = 0
    fail_count = 0
    started = time.time()

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(run_member_entry, member, signal, tg_id) for tg_id, member in eligible]
        for fut in as_completed(futures):
            tg_id, ok, detail = fut.result()
            if ok:
                ok_count += 1
                log(f"[ORDER SUCCESS] tg={tg_id} {signal.get('coin')} {signal.get('foreign')} pos={detail}")
            else:
                fail_count += 1
                log(f"[ORDER FAIL/SKIP] tg={tg_id} {signal.get('coin')} {signal.get('foreign')} / {detail}")

    elapsed = time.time() - started
    log(f"[ORDER RESULT] {signal.get('coin')} {signal.get('domestic')}->{signal.get('foreign')} ok={ok_count} fail={fail_count} skipped={skipped} elapsed={elapsed:.2f}s workers={max_workers}")

def poll_once(processed: Set[str]) -> Set[str]:
    if not os.path.exists(ORDER_QUEUE_PATH):
        return processed
    offset = get_offset()
    with open(ORDER_QUEUE_PATH, "rb") as f:
        f.seek(offset)
        while True:
            pos_before = f.tell()
            raw = f.readline()
            if not raw:
                set_offset(pos_before)
                break
            try:
                line = raw.decode("utf-8").strip()
                if not line:
                    continue
                item = json.loads(line)
                signal = item.get("signal") or {}
                signal_id = str(item.get("signal_id") or signal.get("signal_id") or "")
                queued_ts = float(item.get("queued_ts") or 0.0)
                age = time.time() - queued_ts if queued_ts else 0.0
                if not signal_id:
                    continue
                if signal_id in processed:
                    continue
                if QUEUE_ITEM_MAX_AGE_SEC > 0 and age > QUEUE_ITEM_MAX_AGE_SEC:
                    print(f"[ORDER SKIP] stale signal age={age:.1f}s signal_id={signal_id}")
                    mark_processed(signal_id, "STALE")
                    processed.add(signal_id)
                    continue
                print(f"[ORDER PICK] {signal.get('coin')} {signal.get('domestic')}->{signal.get('foreign')} age={age:.2f}s signal_id={signal_id}")
                process_signal(signal)
                mark_processed(signal_id, "DONE")
                processed.add(signal_id)
            except Exception as e:
                print(f"[ORDER ERROR] {e}")
                traceback.print_exc()
        set_offset(f.tell())
    return processed


def main():
    print("="*70)
    print("K-EDGE V9.5.2d ORDER WORKER PARALLEL + DUPLICATE ACTIVE LOCK")
    print("Queue:", ORDER_QUEUE_PATH)
    print(f"Parallel workers: {ORDER_WORKER_MAX_PARALLEL}")
    print("Stop: Ctrl+C")
    print("="*70)
    processed = load_processed()
    while True:
        processed = poll_once(processed)
        time.sleep(ORDER_WORKER_POLL_SEC)


if __name__ == "__main__":
    main()
