@echo off
title K-EDGE AUTO V9.4.3 AUTO_SETTINGS
cd /d "%~dp0"
echo ========================================
echo K-EDGE AUTO V9.4.3 AUTO SETTINGS LINK
echo ========================================
start "MEXC" cmd /k py "kedge_v9_3_2_BITHUMB_TO_MEXC_AUTO_PAPER_TEST_CAP_FEE_SLOW.py"
start "GATE" cmd /k py "kedge_v9_3_1_BITHUMB_TO_GATE_AUTO_PAPER_TEST_CAP_FEE.py"
start "BITGET" cmd /k py "kedge_v9_3_1_BITHUMB_TO_BITGET_AUTO_PAPER_TEST_CAP_FEE.py"
start "BINGX" cmd /k py "kedge_v9_3_1_BITHUMB_TO_BINGX_AUTO_PAPER_TEST_CAP_FEE.py"
start "STORAGE" cmd /k py "kedge_storage_worker_v931_test_cap_fee.py"
echo.
echo ALL 5 PROCESS STARTED
pause
