@echo off
chcp 65001 >nul
title K-EDGE AUTO V9.4 PAPER TEST
cd /d %~dp0

echo ============================================================
echo K-EDGE AUTO V9.4 PAPER TEST START
echo - 반자동 폐기 / AUTO 전용
echo - MEXC 파일만 callback poller ON
echo - 나머지 3개 거래소는 스캔/알림/자동진입만 실행
echo ============================================================

start "KEDGE_STORAGE_WORKER" cmd /k "py kedge_storage_worker_v931_test_cap_fee.py"

start "KEDGE_BINGX_AUTO" cmd /k "set ENABLE_CALLBACK_POLLER=false&& py kedge_v9_3_1_BITHUMB_TO_BINGX_AUTO_PAPER_TEST_CAP_FEE.py"
start "KEDGE_BITGET_AUTO" cmd /k "set ENABLE_CALLBACK_POLLER=false&& py kedge_v9_3_1_BITHUMB_TO_BITGET_AUTO_PAPER_TEST_CAP_FEE.py"
start "KEDGE_GATE_AUTO" cmd /k "set ENABLE_CALLBACK_POLLER=false&& py kedge_v9_3_1_BITHUMB_TO_GATE_AUTO_PAPER_TEST_CAP_FEE.py"
start "KEDGE_MEXC_AUTO_CALLBACK" cmd /k "set ENABLE_CALLBACK_POLLER=true&& py kedge_v9_3_2_BITHUMB_TO_MEXC_AUTO_PAPER_TEST_CAP_FEE_SLOW.py"

echo 실행 명령 전송 완료.
echo 열린 CMD 창 5개를 확인하세요.
pause
