@echo off
cd /d "%~dp0"

set SUPABASE_URL=https://qakhbihueonefzifrmct.supabase.co
set SUPABASE_SERVICE_KEY=sb_publishable_XboBFueAITcieSL75B2S5g_qlm4XmOm

REM V8 실전가상 동적 슬리피지 모드
REM 실제 주문 안 나감 / API 검사 SKIP / 실패 시 금액 초기화
REM 고정 0.5%%가 아니라 "현재 실제엣지 - 2%%" 만큼 체결범위 계산
REM 예: 실제엣지 4%% -> 허용 슬리피지 2%% / 실제엣지 2.1%% -> 0.1%%

set REAL_ORDER_ENABLED=false
set PAPER_TRADING_ENABLED=true
set MIN_RETAIN_EDGE_PERCENT=2.0

start "BITHUMB-MEXC-CALLBACK-V8-PAPER" cmd /k "set ENABLE_CALLBACK_POLLER=true&& py domestic_spot_to_foreign_futures_bot_BITHUMB_TO_MEXC_ONLY_SPEED_TEST_DM_STATE_SAFE_SINGLE_CALLBACK_V8_DYNAMIC_SLIPPAGE.py"
start "BITHUMB-GATE-V8-PAPER" cmd /k "set ENABLE_CALLBACK_POLLER=false&& py domestic_spot_to_foreign_futures_bot_BITHUMB_TO_GATE_ONLY_SPEED_TEST_DM_STATE_SAFE_SINGLE_CALLBACK_V8_DYNAMIC_SLIPPAGE.py"
start "BITHUMB-BITGET-V8-PAPER" cmd /k "set ENABLE_CALLBACK_POLLER=false&& py domestic_spot_to_foreign_futures_bot_BITHUMB_TO_BITGET_ONLY_SPEED_TEST_DM_STATE_SAFE_SINGLE_CALLBACK_V8_DYNAMIC_SLIPPAGE.py"
start "BITHUMB-BINGX-V8-PAPER" cmd /k "set ENABLE_CALLBACK_POLLER=false&& py domestic_spot_to_foreign_futures_bot_BITHUMB_TO_BINGX_ONLY_SPEED_TEST_DM_STATE_SAFE_SINGLE_CALLBACK_V8_DYNAMIC_SLIPPAGE.py"

pause
