V8 실전가상 동적 슬리피지 + 데이터 저장 완성본

핵심 변경:
- 기존 고정 0.5% 체결벽 기준을 제거
- 신규 기준:
  허용 슬리피지 = 현재 실제엣지 - 최소 유지엣지 2%
- 예:
  실제엣지 2.1% -> 허용 슬리피지 0.1%
  실제엣지 2.5% -> 허용 슬리피지 0.5%
  실제엣지 4.0% -> 허용 슬리피지 2.0%
  실제엣지 5.0% -> 허용 슬리피지 3.0%

포함:
- 실제 주문 안 나감: REAL_ORDER_ENABLED=false
- API/잔고 검사 SKIP
- 실패 시 선택금액 0원 초기화
- 국내/해외 진입금액 표시
- CSV 저장 유지
- CSV에 allowed_slippage_percent, min_retain_edge_percent 저장
- 체결범위별 가능금액 표시
- 버튼 중복 방지 유지

저장 위치:
양방봇\paper_trading_data\paper_entries.csv
양방봇\paper_trading_data\trade_results.csv
양방봇\paper_trading_data\daily_stats.json

실행:
start_all_4exchange_V8_DYNAMIC_SLIPPAGE.bat
